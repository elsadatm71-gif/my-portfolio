#include <Servo.h>

// ============================================================
// Arduino UNO Servo Gripper Controller
//
// Commands from Python over USB Serial:
// OPEN
// CLOSE
// TEST
// STATUS
// ANGLE 90
//
// Replies:
// GRIPPER_READY
// OK_OPEN
// OK_CLOSE
// OK_TEST
// OK_READY
// OK_ANGLE <angle>
// ERROR_UNKNOWN_COMMAND
// ERROR_ANGLE_OUT_OF_RANGE
//
// Serial baud: 9600
// Line ending: Newline
// ============================================================


// ------------------------------------------------------------
// SAFETY MODE
//
// Keep false while servo is burned / not connected.
// This lets you test Python <-> Arduino communication safely.
// ------------------------------------------------------------

const bool SERVO_ENABLED = true;


// ------------------------------------------------------------
// SERVO SETTINGS
// ------------------------------------------------------------

Servo gripper;

const int SERVO_PIN = 9;

// Start with safe angles.
// Do NOT use 0 or 180 at first.
const int OPEN_ANGLE = 60;
const int CLOSE_ANGLE = 150;

const int STEP_DELAY_MS = 15;

int currentAngle = OPEN_ANGLE;


// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  Serial.begin(9600);

  if (SERVO_ENABLED) {
    gripper.attach(SERVO_PIN);
    gripper.write(OPEN_ANGLE);
    currentAngle = OPEN_ANGLE;
  }

  Serial.println("GRIPPER_READY");

  if (SERVO_ENABLED) {
    Serial.println("SERVO_MODE");
  } else {
    Serial.println("SIMULATION_MODE");
  }

  Serial.println("Commands: OPEN, CLOSE, TEST, STATUS, ANGLE 90");
}


// ------------------------------------------------------------
// MAIN LOOP
// ------------------------------------------------------------

void loop() {
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    command.trim();
    command.toUpperCase();

    if (command == "OPEN") {
      openGripper();
    }
    else if (command == "CLOSE") {
      closeGripper();
    }
    else if (command == "TEST") {
      testGripper();
    }
    else if (command == "STATUS") {
      statusGripper();
    }
    else if (command.startsWith("ANGLE")) {
      handleAngleCommand(command);
    }
    else {
      Serial.print("ERROR_UNKNOWN_COMMAND ");
      Serial.println(command);
    }
  }
}


// ------------------------------------------------------------
// OPEN GRIPPER
// ------------------------------------------------------------

void openGripper() {
  Serial.println("OPENING_GRIPPER");

  if (SERVO_ENABLED) {
    moveServoSmooth(currentAngle, OPEN_ANGLE);
    currentAngle = OPEN_ANGLE;
  } else {
    delay(300);
  }

  Serial.println("OK_OPEN");
}


// ------------------------------------------------------------
// CLOSE GRIPPER
// ------------------------------------------------------------

void closeGripper() {
  Serial.println("CLOSING_GRIPPER");

  if (SERVO_ENABLED) {
    moveServoSmooth(currentAngle, CLOSE_ANGLE);
    currentAngle = CLOSE_ANGLE;
  } else {
    delay(300);
  }

  Serial.println("OK_CLOSE");
}


// ------------------------------------------------------------
// TEST GRIPPER
// ------------------------------------------------------------

void testGripper() {
  Serial.println("TESTING_GRIPPER");

  closeGripper();
  delay(500);
  openGripper();

  Serial.println("OK_TEST");
}


// ------------------------------------------------------------
// STATUS
// ------------------------------------------------------------

void statusGripper() {
  Serial.println("OK_READY");

  if (SERVO_ENABLED) {
    Serial.print("CURRENT_ANGLE ");
    Serial.println(currentAngle);
  } else {
    Serial.println("SIMULATION_MODE");
  }
}


// ------------------------------------------------------------
// MANUAL ANGLE COMMAND
//
// Example:
// ANGLE 80
// ------------------------------------------------------------

void handleAngleCommand(String command) {
  int spaceIndex = command.indexOf(' ');

  if (spaceIndex < 0) {
    Serial.println("ERROR_USE_ANGLE_SPACE_NUMBER");
    return;
  }

  int angle = command.substring(spaceIndex + 1).toInt();

  // Safe range first. Avoid 0 and 180.
  if (angle < 20 || angle > 160) {
    Serial.println("ERROR_ANGLE_OUT_OF_RANGE");
    return;
  }

  Serial.print("MOVING_TO_ANGLE ");
  Serial.println(angle);

  if (SERVO_ENABLED) {
    moveServoSmooth(currentAngle, angle);
    currentAngle = angle;
  } else {
    delay(300);
    currentAngle = angle;
  }

  Serial.print("OK_ANGLE ");
  Serial.println(angle);
}


// ------------------------------------------------------------
// SMOOTH SERVO MOVEMENT
// ------------------------------------------------------------

void moveServoSmooth(int startAngle, int endAngle) {
  if (startAngle < endAngle) {
    for (int angle = startAngle; angle <= endAngle; angle++) {
      gripper.write(angle);
      delay(STEP_DELAY_MS);
    }
  } else {
    for (int angle = startAngle; angle >= endAngle; angle--) {
      gripper.write(angle);
      delay(STEP_DELAY_MS);
    }
  }
}