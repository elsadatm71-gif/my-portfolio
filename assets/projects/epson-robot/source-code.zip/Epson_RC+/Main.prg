' ============================================================
' Cargo Storing System
' Epson RC+ / SPEL+
'
' PICK AND PLACE TEST VERSION
'
' Required taught points:
' P0  = SAFE_HOME / waiting position
' P90 = ARUCO_ORIGIN / point above origin ArUco marker
' P10 = PLACE_A
' P11 = PLACE_B
' P12 = PLACE_C
'
' Python sends:
' X_mm,Y_mm,U_deg,DEST
'
' Example:
' 76.36,146.02,-3.39,C
'
' RC+ sends gripper commands to Python:
' GRIPPER_OPEN
' GRIPPER_CLOSE
'
' Python replies:
' OK_OPEN
' OK_CLOSE
' ERROR_OPEN
' ERROR_CLOSE
'
' Z values:
' pickDownZ  = -20.878
' placeDownZ = -10.878
' safeZ      = 0
' ============================================================


Function main

    Integer netPort
    Integer tokenCount
    Integer lineCount
    Integer xSign, ySign
    Integer swapXY
    Integer gripperOK

    String rxLine$
    String tokens$(10)
    String dest$

    Real camXmm, camYmm
    Real camU
    Real originRobotX, originRobotY
    Real pickX, pickY, pickU
    Real safeZ, pickDownZ, placeDownZ

    netPort = 201

    Print "Starting Pick and Place Test"
    Print "RC+ will wait for Python/OpenCV data."

    Motor On
    Power Low
    Speed 10
    Accel 10, 10

    ' -------------------------------------------------
    ' AXIS MAPPING SETTINGS
    '
    ' Camera is top-view but rotated compared to robot.
    ' swapXY = 1 means:
    ' pickX uses camY
    ' pickY uses camX
    ' -------------------------------------------------

    swapXY = 1
    xSign = 1
    ySign = -1

    ' -------------------------------------------------
    ' P90 = origin marker position
    ' P0  = safe rest/waiting position
    ' -------------------------------------------------

    originRobotX = CX(P90)
    originRobotY = CY(P90)

    Print "Robot origin from P90:"
    Print "originRobotX = ", originRobotX
    Print "originRobotY = ", originRobotY

    Print "Axis mapping:"
    Print "swapXY = ", swapXY
    Print "xSign = ", xSign
    Print "ySign = ", ySign

    ' -------------------------------------------------
    ' Z SETTINGS
    ' -------------------------------------------------

    safeZ = -13
    pickDownZ = -48.878
    placeDownZ = -8.878

    Print "Z settings:"
    Print "safeZ = ", safeZ
    Print "pickDownZ = ", pickDownZ
    Print "placeDownZ = ", placeDownZ


ReconnectTCP:

    OnErr GoTo GeneralError

    Print "Opening TCP server..."
    OpenNet #netPort As Server

    Print "Waiting for Python connection..."
    WaitNet #netPort

    Print "Python connected to robot controller."

    Do

        Print "Waiting for new cargo data..."

        lineCount = 0

        Do
            lineCount = Lof(netPort)

            If lineCount > 0 Then
                Exit Do
            EndIf

            Wait 0.05
        Loop

        Line Input #netPort, rxLine$
        rxLine$ = CleanTcpLine$(rxLine$)

        If rxLine$ = "" Then

            Print "Empty TCP line skipped."

        ElseIf UCase$(rxLine$) = "STOP" Then

            Print "STOP command received from Python."
            Exit Do

        Else

            Print "Received: ", rxLine$

            tokenCount = ParseStr(rxLine$, tokens$(), ",")

            If tokenCount <> 4 Then

                Print "ERROR: Bad data format."
                Print "Expected: X_mm,Y_mm,U_deg,DEST"

            Else

                camXmm = Val(tokens$(0))
                camYmm = Val(tokens$(1))
                camU = Val(tokens$(2))
                dest$ = UCase$(Trim$(tokens$(3)))

                pickU = 0

                ' -------------------------------------------------
                ' CAMERA TO ROBOT CONVERSION
                ' -------------------------------------------------

                If swapXY = 0 Then

                    pickX = originRobotX + (xSign * camXmm)
                    pickY = originRobotY + (ySign * camYmm)

                Else

                    pickX = originRobotX + (xSign * camYmm)
                    pickY = originRobotY + (ySign * camXmm)

                EndIf

                Print "Parsed camera data:"
                Print "camXmm = ", camXmm
                Print "camYmm = ", camYmm
                Print "camU   = ", camU
                Print "dest   = ", dest$

                Print "Converted robot pick coordinates:"
                Print "pickX = ", pickX
                Print "pickY = ", pickY
                Print "pickU = ", pickU

                If IsPickPositionSafe(pickX, pickY) = False Then

                    Print "ERROR: Pick position outside software workspace."
                    Print "Robot will not move."

                Else

                    If dest$ = "A" Then

                        Print "Destination A selected."
                        Print "Robot will place at P10."

                    ElseIf dest$ = "B" Then

                        Print "Destination B selected."
                        Print "Robot will place at P11."

                    ElseIf dest$ = "C" Then

                        Print "Destination C selected."
                        Print "Robot will place at P12."

                    Else

                        Print "ERROR: Unknown destination."
                        Print "Destination must be A, B, or C."
                        GoTo SkipThisBox

                    EndIf

                    ' -------------------------------------------------
                    ' REACHABILITY CHECKS
                    ' -------------------------------------------------

                    If TargetOK(XY(pickX, pickY, safeZ, pickU)) = False Then
                        Print "ERROR: Pick safe target is not reachable."
                        Print "pickX = ", pickX
                        Print "pickY = ", pickY
                        GoTo SkipThisBox
                    EndIf

                    If TargetOK(XY(pickX, pickY, pickDownZ, pickU)) = False Then
                        Print "ERROR: Pick down target is not reachable."
                        Print "pickDownZ = ", pickDownZ
                        GoTo SkipThisBox
                    EndIf

                    ' -------------------------------------------------
                    ' PICK SEQUENCE
                    ' -------------------------------------------------

                    Print "Moving to safe waiting point P0."
                    Go P0
                    Wait 0.5

                    Print "Moving above detected box."
                    Go XY(pickX, pickY, safeZ, pickU)
                    Wait 0.5

                    Print "Requesting gripper open before pick."
                    gripperOK = RequestGripperOpen(netPort)

                    If gripperOK = 0 Then
                        Print "ERROR: Gripper did not open."
                        GoTo SkipThisBox
                    EndIf

                    Print "Moving down to pick height."
                    Go XY(pickX, pickY, pickDownZ, pickU)
                    Wait 0.5

                    Print "Requesting gripper close."
                    gripperOK = RequestGripperClose(netPort)

                    If gripperOK = 0 Then
                        Print "ERROR: Gripper did not close."
                        Go XY(pickX, pickY, safeZ, pickU)
                        GoTo SkipThisBox
                    EndIf

                    Print "Gripper closed. Lifting Z to safe height."
                    Go XY(pickX, pickY, safeZ, pickU)
                    Wait 0.5

                    ' -------------------------------------------------
                    ' PLACE SEQUENCE
                    ' -------------------------------------------------

                    If dest$ = "A" Then
                        Call PlaceBoxA(netPort, safeZ, placeDownZ)
                    ElseIf dest$ = "B" Then
                        Call PlaceBoxB(netPort, safeZ, placeDownZ)
                    ElseIf dest$ = "C" Then
                        Call PlaceBoxC(netPort, safeZ, placeDownZ)
                    EndIf

                    Print "Returning to safe waiting point P0."
                    Go P0
                    Wait 0.5

                    Print "Pick and place cycle finished."

                EndIf

            EndIf

        EndIf

SkipThisBox:

        Wait 0.1

    Loop

    CloseNet #netPort
    Motor Off

    Print "Pick and Place Test stopped."
    Exit Function


GeneralError:

    Print "Robot or TCP error happened."
    Print "Error number: ", Err
    Print "Error message: ", ErrMsg$(Err)

    CloseNet #netPort
    Wait 1

    Print "Restarting TCP server..."
    EResume ReconnectTCP

Fend


' ============================================================
' CLEAN TCP LINE
' ============================================================

Function CleanTcpLine$(lineIn$ As String) As String

    Integer i
    Integer n
    String ch$
    String out$

    out$ = ""
    n = Len(lineIn$)

    For i = 1 To n
        ch$ = Mid$(lineIn$, i, 1)

        If ch$ <> Chr$(10) Then
            If ch$ <> Chr$(13) Then
                out$ = out$ + ch$
            EndIf
        EndIf
    Next

    CleanTcpLine$ = Trim$(out$)

Fend


' ============================================================
' WAIT FOR GRIPPER RESPONSE
' ============================================================

Function WaitForGripperResponse(netPort As Integer, expected$ As String) As Integer

    Integer lineCount
    Integer timeoutCounter
    String response$

    WaitForGripperResponse = 0
    timeoutCounter = 0

    Do
        lineCount = Lof(netPort)

        If lineCount > 0 Then

            Line Input #netPort, response$
            response$ = CleanTcpLine$(response$)
            response$ = UCase$(Trim$(response$))

            Print "Gripper response from Python: ", response$

            If response$ = expected$ Then
                WaitForGripperResponse = 1
                Exit Function
            EndIf

            If Left$(response$, 5) = "ERROR" Then
                WaitForGripperResponse = 0
                Exit Function
            EndIf

        EndIf

        Wait 0.1
        timeoutCounter = timeoutCounter + 1

        If timeoutCounter > 150 Then
            Print "ERROR: Gripper response timeout."
            WaitForGripperResponse = 0
            Exit Function
        EndIf

    Loop

Fend


' ============================================================
' REQUEST GRIPPER OPEN
' ============================================================

Function RequestGripperOpen(netPort As Integer) As Integer

    Print "Sending command to Python: GRIPPER_OPEN"
    Print #netPort, "GRIPPER_OPEN"

    RequestGripperOpen = WaitForGripperResponse(netPort, "OK_OPEN")

Fend


' ============================================================
' REQUEST GRIPPER CLOSE
' ============================================================

Function RequestGripperClose(netPort As Integer) As Integer

    Print "Sending command to Python: GRIPPER_CLOSE"
    Print #netPort, "GRIPPER_CLOSE"

    RequestGripperClose = WaitForGripperResponse(netPort, "OK_CLOSE")

Fend


' ============================================================
' PLACE A
' ============================================================

Function PlaceBoxA(netPort As Integer, safeZ As Real, downZ As Real)

    Integer gripperOK
    Real x, y, u

    x = CX(P10)
    y = CY(P10)
    u = CU(P10)

    Print "Moving above storage position A: P10."
    Go P10
    Wait 0.5

    Print "Moving down at A."
    Go XY(x, y, downZ, u)
    Wait 0.5

    Print "Requesting gripper open at A."
    gripperOK = RequestGripperOpen(netPort)

    If gripperOK = 0 Then
        Print "ERROR: Gripper did not open at A."
        Exit Function
    EndIf

    Print "Box released at A."
    Print "Lifting Z to safe height before moving away."
    Go XY(x, y, safeZ, u)
    Wait 0.5

Fend


' ============================================================
' PLACE B
' ============================================================

Function PlaceBoxB(netPort As Integer, safeZ As Real, downZ As Real)

    Integer gripperOK
    Real x, y, u

    x = CX(P11)
    y = CY(P11)
    u = CU(P11)

    Print "Moving above storage position B: P11."
    Go P11
    Wait 0.5

    Print "Moving down at B."
    Go XY(x, y, downZ, u)
    Wait 0.5

    Print "Requesting gripper open at B."
    gripperOK = RequestGripperOpen(netPort)

    If gripperOK = 0 Then
        Print "ERROR: Gripper did not open at B."
        Exit Function
    EndIf

    Print "Box released at B."
    Print "Lifting Z to safe height before moving away."
    Go XY(x, y, safeZ, u)
    Wait 0.5

Fend


' ============================================================
' PLACE C
' ============================================================

Function PlaceBoxC(netPort As Integer, safeZ As Real, downZ As Real)

    Integer gripperOK
    Real x, y, u

    x = CX(P12)
    y = CY(P12)
    u = CU(P12)

    Print "Moving above storage position C: P12."
    Go P12
    Wait 0.5

    Print "Moving down at C."
    Go XY(x, y, downZ, u)
    Wait 0.5

    Print "Requesting gripper open at C."
    gripperOK = RequestGripperOpen(netPort)

    If gripperOK = 0 Then
        Print "ERROR: Gripper did not open at C."
        Exit Function
    EndIf

    Print "Box released at C."
    Print "Lifting Z to safe height before moving away."
    Go XY(x, y, safeZ, u)
    Wait 0.5

Fend


' ============================================================
' PICK POSITION SAFETY CHECK
' ============================================================

Function IsPickPositionSafe(x As Real, y As Real) As Boolean

    If x < -395 Then
        IsPickPositionSafe = False
        Exit Function
    EndIf

    If x > 395 Then
        IsPickPositionSafe = False
        Exit Function
    EndIf

    If y < -395 Then
        IsPickPositionSafe = False
        Exit Function
    EndIf

    If y > 395 Then
        IsPickPositionSafe = False
        Exit Function
    EndIf

    IsPickPositionSafe = True

Fend
