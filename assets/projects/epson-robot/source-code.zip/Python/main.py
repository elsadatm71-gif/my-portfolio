"""
ESP32-CAM → Epson T3-401S SCARA Vision System with Multiple ArUco Markers

This system:
- Detects origin marker (fixed on table, defines world origin)
- Detects box markers (attached to boxes, identifies destination)
- Calculates box positions relative to origin in centimeters
- Logs detected coordinates to CSV for validation
- Filters and validates coordinate stability
- Currently focused on vision system accuracy (no robot commands yet)

The origin marker defines world coordinates (0, 0).
Each box marker is identified by its marker ID which maps to a destination (A, B, C, D).
"""

import argparse
import csv
import math
import os
import sys
import time
from collections import deque
from datetime import datetime

import cv2
import numpy as np
import serial

from src.camera import ESP32Camera
from src.comm import PersistentTCPSender
from src.aruco_multi import MultiMarkerDetector
from src.coordinate_transform import (
    calculate_relative_pose,
    to_int_point,
)
from src.smoothing import PerMarkerCoordinateFilter, PerMarkerStabilityChecker
from src.marker_config import ORIGIN_MARKER_ID, DESTINATION_MAP



class FrameRate:
    """Simple FPS counter."""
    def __init__(self, window_size=15):
        self.window_size = window_size
        self.times = deque(maxlen=window_size)

    def update(self):
        self.times.append(time.time())
        if len(self.times) < 2:
            return 0.0
        elapsed = self.times[-1] - self.times[0]
        return len(self.times) / max(elapsed, 1e-6)


class DetectionLogger:
    """Log detected box coordinates to CSV with validation data."""
    def __init__(self, csv_path):
        self.csv_path = csv_path
        self._ensure_header()

    def _ensure_header(self):
        created = not os.path.exists(self.csv_path)
        self.file = open(self.csv_path, "a", newline="")
        self.writer = csv.writer(self.file)
        if created or os.path.getsize(self.csv_path) == 0:
            self.writer.writerow([
                "timestamp",
                "box_marker_id",
                "destination",
                "x_cm",
                "y_cm",
                "angle_deg",
                "distance_cm",
                "stable",
            ])
            self.file.flush()

    def log(self, box_id, destination, x_cm, y_cm, angle_deg, distance_cm, stable):
        """Log detection."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        self.writer.writerow([
            timestamp,
            box_id,
            destination,
            f"{x_cm:.3f}",
            f"{y_cm:.3f}",
            f"{angle_deg:.2f}",
            f"{distance_cm:.3f}",
            "1" if stable else "0",
        ])
        self.file.flush()

    def close(self):
        try:
            self.file.close()
        except Exception:
            pass




def compute_reprojection_error(marker_corners, camera_matrix, dist, rvec, tvec, marker_size_cm):
    """Compute reprojection error to assess calibration quality."""
    half = marker_size_cm / 100.0 / 2.0  # convert to meters
    object_points = np.array([
        [-half, half, 0.0],
        [half, half, 0.0],
        [half, -half, 0.0],
        [-half, -half, 0.0],
    ], dtype=np.float32)
    
    image_points, _ = cv2.projectPoints(object_points, rvec, tvec, camera_matrix, dist)
    image_points = image_points.reshape(-1, 2)
    marker_corners = np.asarray(marker_corners, dtype=np.float32).reshape(-1, 2)
    errors = np.linalg.norm(image_points - marker_corners, axis=1)
    return float(errors.mean())


def draw_line_between_points(frame, p1, p2, color=(255, 255, 0), thickness=2):
    """Draw line between two points with proper int conversion."""
    pt1 = to_int_point(p1)
    pt2 = to_int_point(p2)
    cv2.line(frame, pt1, pt2, color, thickness, lineType=cv2.LINE_AA)


def draw_circle_at_point(frame, center, radius=5, color=(0, 255, 0), thickness=-1):
    """Draw circle at point with proper int conversion."""
    pt = to_int_point(center)
    cv2.circle(frame, pt, int(radius), color, thickness)


def draw_text_at_point(frame, text, position, font_scale=0.6, color=(255, 255, 255), thickness=1):
    """Draw text at position with proper int conversion."""
    pt = to_int_point(position)
    cv2.putText(frame, text, pt, cv2.FONT_HERSHEY_SIMPLEX, font_scale, color, thickness, cv2.LINE_AA)


def draw_text_overlay(frame, lines, x_offset=10, y_offset=30, line_height=22):
    """Draw multi-line text overlay with background."""
    for idx, line in enumerate(lines):
        y = y_offset + idx * line_height
        draw_text_at_point(frame, line, (x_offset, y), font_scale=0.55)


def draw_warnings(frame, warnings):
    """Draw warning messages in red at bottom of frame."""
    if not warnings:
        return
    height = frame.shape[0]
    for idx, warning in enumerate(warnings):
        y = height - 20 - idx * 22
        draw_text_at_point(frame, f"⚠ {warning}", (10, y), font_scale=0.5, color=(0, 0, 255), thickness=2)


class ArduinoGripperClient:
    """Arduino gripper controller over USB serial."""

    def __init__(self, port, baudrate=9600, simulate=False, debug=False, timeout=2.0):
        self.port = port
        self.baudrate = baudrate
        self.simulate = simulate
        self.debug = debug
        self.timeout = timeout
        self._serial = None

        if self.simulate:
            if self.debug:
                print(f"[SIMULATE] ArduinoGripperClient initialized for {port}@{baudrate}")
            return

        self._serial = serial.Serial(port, baudrate, timeout=timeout)
        if self.debug:
            print(f"Opened serial port {port} at {baudrate} baud")

        time.sleep(2.0)
        self._drain_startup_lines()
        self._initialize_ready_state()

    def _read_line(self, timeout=None):
        if timeout is None:
            timeout = self.timeout
        deadline = time.time() + timeout
        while time.time() < deadline:
            raw_line = self._serial.readline()
            if not raw_line:
                continue
            line = raw_line.decode("ascii", errors="ignore").strip()
            if line:
                return line
        return None

    def _drain_startup_lines(self):
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            line = self._read_line(timeout=0.2)
            if line is None:
                break
            print(f"Arduino startup: {line}")
            continue

    def _initialize_ready_state(self):
        self._serial.reset_input_buffer()
        payload = "STATUS\n".encode("ascii")
        if self.debug:
            print("Sending gripper STATUS command for initialization")
        self._serial.write(payload)
        self._serial.flush()

        deadline = time.time() + self.timeout
        while time.time() < deadline:
            raw_line = self._serial.readline()
            if not raw_line:
                continue
            line = raw_line.decode("ascii", errors="ignore").strip()
            if not line:
                continue
            print(f"Arduino startup: {line}")
            if line == "OK_READY":
                if self.debug:
                    print("✓ Gripper ready")
                return
            continue

        raise TimeoutError("Timeout waiting for OK_READY from Arduino")

    def _send_command(self, command, expected_reply, ignore_lines=None):
        if self.simulate:
            print(f"[SIMULATE] Gripper command: {command}")
            return True

        if not self._serial or not self._serial.is_open:
            raise RuntimeError("Gripper serial port is not open")

        if ignore_lines is None:
            ignore_lines = []

        payload = f"{command}\n".encode("ascii")
        if self.debug:
            print(f"Sending gripper command: {command}")

        try:
            self._serial.reset_input_buffer()
        except Exception:
            pass

        self._serial.write(payload)
        self._serial.flush()

        deadline = time.time() + self.timeout
        while time.time() < deadline:
            raw_line = self._serial.readline()
            if not raw_line:
                continue
            line = raw_line.decode("ascii", errors="ignore").strip()
            if not line:
                continue
            if self.debug:
                print(f"Gripper reply: {line}")
            if line == expected_reply:
                return True
            if line in ignore_lines:
                continue
            print(f"Arduino unexpected reply: {line}")
            continue

        raise TimeoutError(f"Timeout waiting for gripper reply to {command}")

    def open_gripper(self):
        return self._send_command("OPEN", "OK_OPEN", ignore_lines=["OPENING_GRIPPER"])

    def close_gripper(self):
        return self._send_command("CLOSE", "OK_CLOSE", ignore_lines=["CLOSING_GRIPPER"])

    def test_gripper(self):
        if self.simulate:
            print("[SIMULATE] Gripper test")
            return True
        return self._send_command("TEST", "OK_TEST")

    def status(self):
        if self.simulate:
            print("[SIMULATE] Gripper status")
            return "OK_READY"
        if self._send_command("STATUS", "OK_READY"):
            return "OK_READY"
        return "ERROR_STATUS"

    def close(self):
        try:
            if self._serial and self._serial.is_open:
                self._serial.close()
                if self.debug:
                    print("Closed gripper serial port")
        except Exception as exc:
            if self.debug:
                print(f"Error closing gripper serial port: {exc}")


def process_robot_commands(tcp_sender, gripper_client, debug=False):
    """Process pending RC+ commands from the robot socket."""
    if not tcp_sender or not tcp_sender.is_connected:
        return []

    lines = tcp_sender.receive_lines(timeout=0.0)
    if not lines:
        return []

    processed_commands = []
    for raw_command in lines:
        command = raw_command.strip().upper().replace(" ", "_")
        if command not in ("GRIPPER_OPEN", "GRIPPER_CLOSE"):
            if debug:
                print(f"Ignoring unsupported RC+ command: {raw_command}")
            continue

        processed_commands.append(command)
        if debug:
            print(f"Received RC+ command: {raw_command} -> {command}")

        if gripper_client is None:
            error_response = "ERROR_OPEN" if command == "GRIPPER_OPEN" else "ERROR_CLOSE"
            if debug:
                print(f"No gripper client available; replying {error_response}")
            tcp_sender.send_response(error_response)
            continue

        try:
            if command == "GRIPPER_OPEN":
                gripper_client.open_gripper()
                tcp_sender.send_response("OK_OPEN")
            else:
                gripper_client.close_gripper()
                tcp_sender.send_response("OK_CLOSE")
        except Exception as exc:
            error_code = "ERROR_OPEN" if command == "GRIPPER_OPEN" else "ERROR_CLOSE"
            if debug:
                print(f"Gripper command failed ({command}): {exc}")
            tcp_sender.send_response(error_code)

    return processed_commands


def parse_args():
    p = argparse.ArgumentParser(
        description="ESP32-CAM ArUco SCARA Vision System - Multiple Marker Detection"
    )
    p.add_argument("--stream", required=True, help="ESP32-CAM MJPEG stream URL")
    p.add_argument("--marker-size-cm", type=float, default=5.0, help="Marker side length in cm")
    p.add_argument("--origin-marker-id", type=int, default=ORIGIN_MARKER_ID, 
                   help="Origin marker ID (fixed on table)")
    p.add_argument("--calib", default="calibration/calib.npz", help="Calibration file path")
    p.add_argument("--log-csv", default="coordinate_log.csv", help="CSV log file")
    p.add_argument("--stable-frames", type=int, default=5, help="Frames required for stability")
    p.add_argument("--filter-window", type=int, default=6, help="Moving average window")
    p.add_argument("--position-threshold-cm", type=float, default=4.0, 
                   help="Position stability threshold (cm)")
    p.add_argument("--angle-threshold-deg", type=float, default=3.0, 
                   help="Angle stability threshold (degrees)")
    p.add_argument("--robot-host", default="192.168.0.1", help="Robot TCP host")
    p.add_argument("--robot-port", type=int, default=1000, help="Robot TCP port")
    p.add_argument("--send-to-robot", action="store_true", help="Send stable box coordinates to robot")
    p.add_argument("--send-cooldown", type=float, default=3.0, 
                   help="Minimum seconds between sends for same marker")
    p.add_argument("--movement-threshold-mm", type=float, default=50.0,
                   help="Minimum mm movement to resend same marker")
    p.add_argument("--debug", action="store_true", help="Enable debug output")
    p.add_argument("--send-unstable", action="store_true",
                   help="Send marker coordinates even if stability check is false")
    # Box height correction options
    p.add_argument("--box-height-mm", type=float, default=40.0, help="Box height in millimeters for height-based offset")
    p.add_argument("--height-offset-x-factor", type=float, default=0.0, help="Height-based X offset factor (box_height_mm * factor)")
    p.add_argument("--height-offset-y-factor", type=float, default=0.0, help="Height-based Y offset factor (box_height_mm * factor)")
    p.add_argument("--manual-box-offset-x-mm", type=float, default=0.0, help="Manual X offset in mm to add to box coordinate")
    p.add_argument("--manual-box-offset-y-mm", type=float, default=0.0, help="Manual Y offset in mm to add to box coordinate")
    p.add_argument("--use-gripper", action="store_true", help="Enable Arduino gripper control via USB serial")
    p.add_argument("--gripper-port", default="COM8", help="Arduino serial port for gripper communication")
    p.add_argument("--gripper-baud", type=int, default=9600, help="Arduino serial baud rate")
    p.add_argument("--simulate-gripper", action="store_true", help="Simulate Arduino gripper without hardware")
    return p.parse_args()


def main():
    args = parse_args()

    gripper_client = None
    if args.use_gripper or args.simulate_gripper:
        try:
            gripper_client = ArduinoGripperClient(
                port=args.gripper_port,
                baudrate=args.gripper_baud,
                simulate=args.simulate_gripper,
                debug=args.debug,
            )
            status_label = "SIMULATED" if args.simulate_gripper else f"{args.gripper_port}@{args.gripper_baud}"
            print(f"✓ Gripper client initialized: {status_label}")
            if not args.simulate_gripper:
                print("Checking gripper status...")
                gripper_client.status()
                print("✓ Gripper communication status OK")
        except Exception as exc:
            print(f"✗ Gripper initialization failed: {exc}")
            sys.exit(1)
    else:
        print("Gripper support disabled (use --use-gripper or --simulate-gripper to enable)")

    # Load calibration
    try:
        with np.load(args.calib) as calib_data:
            cam_mtx = calib_data["camera_matrix"]
            dist = calib_data["dist_coeffs"]
            print(f"✓ Loaded calibration from {args.calib}")
    except FileNotFoundError:
        print(f"✗ Calibration file not found: {args.calib}")
        print("  Run 'python calibrate.py' to generate it.")
        sys.exit(1)
    except Exception as exc:
        print(f"✗ Failed to load calibration: {exc}")
        sys.exit(1)

    # Initialize components
    cam = ESP32Camera(args.stream)
    detector = MultiMarkerDetector(marker_length_cm=args.marker_size_cm)
    coordinate_filter = PerMarkerCoordinateFilter(window_size=args.filter_window)
    stability_checker = PerMarkerStabilityChecker(
        required_frames=args.stable_frames,
        position_threshold_cm=args.position_threshold_cm,
        angle_threshold_deg=args.angle_threshold_deg
    )
    logger = DetectionLogger(args.log_csv)
    fps_meter = FrameRate()
    last_sent_time_by_marker = {}
    last_sent_pos_by_marker = {}  # Store (x_mm, y_mm, angle_deg) for each marker
    
    # Initialize persistent TCP sender if robot communication is enabled
    tcp_sender = None
    if args.send_to_robot:
        tcp_sender = PersistentTCPSender(
            host=args.robot_host,
            port=args.robot_port,
            debug=args.debug
        )
        print(f"✓ Robot TCP sender initialized: {args.robot_host}:{args.robot_port}")
    else:
        print("Robot communication disabled (use --send-to-robot to enable)")

    window_name = "ESP32-CAM → Epson T3-401S Vision System"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    print(f"\n{'='*60}")
    print("ESP32-CAM → Epson T3-401S Vision System")
    print(f"{'='*60}")
    print(f"Origin marker ID: {args.origin_marker_id}")
    print(f"Destination mapping: {DESTINATION_MAP}")
    print(f"Marker size: {args.marker_size_cm} cm")
    print(f"Coordinate log: {args.log_csv}")
    if args.send_to_robot:
        print(f"Robot communication: ENABLED")
        print(f"  Host: {args.robot_host}:{args.robot_port}")
        print(f"  Send cooldown: {args.send_cooldown}s per marker")
        print(f"  Movement threshold: {args.movement_threshold_mm}mm")
        print(f"  Box height correction: {args.box_height_mm} mm")
        print(f"  Height offsets: X_factor={args.height_offset_x_factor}, Y_factor={args.height_offset_y_factor}")
    print(f"Starting detection...")
    print(f"{'='*60}\n")

    try:
        while True:
            ret, frame = cam.read()
            if not ret:
                time.sleep(0.1)
                continue

            fps = fps_meter.update()
            warnings = []
            messages = []

            robot_commands = []
            robot_busy = False
            if args.send_to_robot and tcp_sender:
                robot_commands = process_robot_commands(tcp_sender, gripper_client, args.debug)
                robot_busy = bool(robot_commands)
                if robot_busy and args.debug:
                    print(f"Skipping coordinate sends while processing RC+ gripper command: {robot_commands}")

            # Detect all markers
            detections = detector.detect(frame, cam_mtx, dist)

            # Separate origin and box markers
            origin_marker_id = args.origin_marker_id
            box_markers = {mid: detections[mid] for mid in detections if mid != origin_marker_id}

            # Check if origin marker is detected
            if origin_marker_id not in detections:
                messages.append("ORIGIN marker NOT detected")
                warnings.append("No origin marker visible")
            else:
                origin_rvec, origin_tvec, origin_corners = detections[origin_marker_id]
                
                # Draw origin marker
                detector.draw_marker(frame, origin_marker_id, cam_mtx, dist, 
                                   label="ORIGIN", color=(0, 255, 0))
                
                # Get reprojection error
                reprojection_error = compute_reprojection_error(
                    origin_corners, cam_mtx, dist, origin_rvec, origin_tvec, args.marker_size_cm
                )

                if robot_commands:
                    messages.append("Robot cmd: " + ", ".join(robot_commands))

                if box_markers:
                    # Process each detected box marker
                    for box_id in sorted(box_markers.keys()):
                        box_rvec, box_tvec, box_corners = box_markers[box_id]
                        
                        # Draw box marker
                        destination = DESTINATION_MAP.get(box_id)
                        destination_label = destination if destination is not None else "?"
                        detector.draw_marker(frame, box_id, cam_mtx, dist, 
                                           label=f"BOX:{box_id}", color=(255, 0, 255))
                        
                        # Calculate position relative to origin (includes relative Z)
                        x_cm, y_cm, angle_deg, distance_cm = calculate_relative_pose(
                            origin_rvec, origin_tvec, box_rvec, box_tvec
                        )

                        # Project box and origin centers to image plane (used for height compensation and drawing)
                        center3d = np.array([[0.0, 0.0, 0.0]], dtype=np.float32)
                        center_px_box, _ = cv2.projectPoints(center3d, box_rvec, box_tvec, cam_mtx, dist)
                        box_center_px = center_px_box[0, 0]

                        origin_px_center, _ = cv2.projectPoints(center3d, origin_rvec, origin_tvec, cam_mtx, dist)
                        origin_center_px = origin_px_center[0, 0]

                        # Apply filtering
                        filtered_x, filtered_y, filtered_angle = coordinate_filter.update(
                            box_id, x_cm, y_cm, angle_deg
                        )
                        
                        # Check stability
                        stable = stability_checker.update(box_id, filtered_x, filtered_y, filtered_angle)
                        
                        # Log detection
                        logger.log(box_id, destination_label, filtered_x, filtered_y, 
                                 filtered_angle, distance_cm, stable)

                        # Send stable coordinates to robot if configured
                        if args.send_to_robot:
                            if robot_busy:
                                if args.debug:
                                    print(f"Marker {box_id}: skipping send because RC+ gripper command is active")
                            elif not tcp_sender or not tcp_sender.is_connected:
                                if args.debug:
                                    print(f"Marker {box_id}: robot sender not connected; skipping send")
                            elif not stable and not args.send_unstable:
                                if args.debug:
                                    print(f"Marker {box_id}: not stable; skipping send")
                            elif destination_label not in ("A", "B", "C"):
                                warning_text = (
                                    f"Marker {box_id} destination '{destination_label}' unsupported"
                                    if destination_label != "?" else
                                    f"Marker {box_id} destination unknown"
                                )
                                warnings.append(warning_text)
                                if args.debug:
                                    print(warning_text)
                            else:
                                # Use pose-based filtered coordinates only
                                u_deg = filtered_angle
                                x_mm = filtered_x * 10.0
                                y_mm = filtered_y * 10.0

                                # Compute manual and height-based correction offsets
                                manual_offset_x_mm = args.manual_box_offset_x_mm
                                manual_offset_y_mm = args.manual_box_offset_y_mm
                                height_offset_x_mm = args.box_height_mm * args.height_offset_x_factor
                                height_offset_y_mm = args.box_height_mm * args.height_offset_y_factor

                                # Corrected coordinates to send to RC+
                                x_mm_corrected = x_mm + manual_offset_x_mm + height_offset_x_mm
                                y_mm_corrected = y_mm + manual_offset_y_mm + height_offset_y_mm

                                if args.debug and (height_offset_x_mm != 0.0 or height_offset_y_mm != 0.0):
                                    print(f"Height correction offsets (mm): X={height_offset_x_mm:.2f}, Y={height_offset_y_mm:.2f}")

                                if abs(x_mm_corrected) > 500 or abs(y_mm_corrected) > 500:
                                    print("ERROR: Refusing to send impossible coordinates")
                                    should_send = False
                                    reason = ""
                                else:
                                    # Debug prints for offsets and values
                                    if args.debug:
                                        pose_x_mm = filtered_x * 10.0
                                        pose_y_mm = filtered_y * 10.0
                                        print(f"Origin tvec (m): {tuple(origin_tvec)}")
                                        print(f"Box tvec (m): {tuple(box_tvec)}")
                                        try:
                                            origin_dist = float(np.linalg.norm(origin_tvec))
                                            box_dist = float(np.linalg.norm(box_tvec))
                                            print(f"Distance from camera (m): origin={origin_dist:.3f} box={box_dist:.3f}")
                                        except Exception:
                                            pass
                                        print(f"Pose-based (mm): X={pose_x_mm:.2f} Y={pose_y_mm:.2f}")
                                        print(f"Selected send (mm): X={x_mm:.2f} Y={y_mm:.2f} U={u_deg:.2f}")
                                        try:
                                            print(f"Raw image centers: origin={tuple(origin_center_px)} box={tuple(box_center_px)}")
                                        except Exception:
                                            pass

                                    # Check if we should send this marker (compare using corrected coords)
                                    should_send = False
                                    reason = ""

                                    now = time.time()
                                    last_pos = last_sent_pos_by_marker.get(box_id)
                                    last_time = last_sent_time_by_marker.get(box_id, 0)

                                    if last_pos is None:
                                        should_send = True
                                        reason = "Sending new marker"
                                        print(f"Sending new marker {box_id}")
                                    else:
                                        last_x, last_y = last_pos
                                        movement_mm = math.hypot(x_mm_corrected - last_x, y_mm_corrected - last_y)
                                        time_elapsed = now - last_time

                                        if movement_mm >= args.movement_threshold_mm and time_elapsed >= args.send_cooldown:
                                            should_send = True
                                            reason = f"Resending marker: moved {movement_mm:.1f} mm"
                                            print(f"Resending marker {box_id}: moved {movement_mm:.1f} mm")
                                        else:
                                            should_send = False
                                            if movement_mm < args.movement_threshold_mm:
                                                print(f"Skipping marker {box_id}: already sent and movement too small ({movement_mm:.1f} mm)")
                                            elif time_elapsed < args.send_cooldown:
                                                if args.debug:
                                                    remaining = args.send_cooldown - time_elapsed
                                                    print(f"Skipping marker {box_id}: cooldown {remaining:.1f}s remaining")
                                            else:
                                                if args.debug:
                                                    print(f"Skipping marker {box_id}: conditions not met")

                                # Send if conditions are met
                                if should_send:
                                    payload = f"{x_mm_corrected:.2f},{y_mm_corrected:.2f},{u_deg:.2f},{destination_label}"
                                    print(f"Sending to robot: {payload}")

                                    if tcp_sender.send(x_mm_corrected, y_mm_corrected, u_deg, destination_label):
                                        last_sent_time_by_marker[box_id] = time.time()
                                        last_sent_pos_by_marker[box_id] = (x_mm_corrected, y_mm_corrected)
                                        if args.debug:
                                            print(f"✓ Sent marker {box_id} to {destination_label} ({reason})")
                                    else:
                                        if args.debug:
                                            print(f"✗ Failed to send marker {box_id}")
                        
                        # box_center_px and origin_center_px already computed above
                        
                        # Draw line from origin to box
                        draw_line_between_points(frame, origin_center_px, box_center_px, 
                                               color=(255, 255, 0), thickness=1)
                        
                        # Draw coordinate info near box
                        info_y_base = int(box_center_px[1]) + 30
                        info_x = int(box_center_px[0])
                        draw_text_at_point(frame, f"ID:{box_id} → {destination}", 
                                        (info_x - 40, info_y_base), font_scale=0.5, color=(255, 0, 255))
                        draw_text_at_point(frame, f"X:{filtered_x:.1f}cm", 
                                        (info_x - 40, info_y_base + 20), font_scale=0.5)
                        draw_text_at_point(frame, f"Y:{filtered_y:.1f}cm", 
                                        (info_x - 40, info_y_base + 40), font_scale=0.5)
                        draw_text_at_point(frame, f"A:{filtered_angle:.1f}°", 
                                        (info_x - 40, info_y_base + 60), font_scale=0.5)
                        draw_text_at_point(frame, f"D:{distance_cm:.1f}cm", 
                                        (info_x - 40, info_y_base + 80), font_scale=0.5)
                        
                        if stable:
                            draw_circle_at_point(frame, box_center_px, radius=8, color=(0, 255, 0), thickness=2)
                        else:
                            draw_circle_at_point(frame, box_center_px, radius=8, color=(0, 165, 255), thickness=2)
                        
                        if args.debug:
                            print(f"Box {box_id} ({destination}): X={filtered_x:.2f}cm, Y={filtered_y:.2f}cm, "
                                  f"A={filtered_angle:.1f}°, stable={stable}, fps={fps:.1f}")
                else:
                    messages.append("No BOX markers detected")
                    warnings.append("Looking for box markers...")

                # Build info messages
                messages = [
                    f"Origin: ID {origin_marker_id}",
                    f"Boxes detected: {len(box_markers)}",
                    f"FPS: {fps:.1f}",
                    f"Calibration error: {reprojection_error:.2f} px",
                ]
                
                if reprojection_error > 3.0:
                    warnings.append(f"High calibration error ({reprojection_error:.1f}px)")
                
                # Check if markers are partially visible
                for corner in origin_corners:
                    c = np.asarray(corner).ravel()
                    cx, cy = float(c[0]), float(c[1])
                    if (cx < 15 or cy < 15 or cx > frame.shape[1] - 15 or cy > frame.shape[0] - 15):
                        warnings.append("Origin marker partially out of view")
                        break
                
                for box_id in box_markers:
                    _, _, corners = box_markers[box_id]
                    for corner in corners:
                        c = np.asarray(corner).ravel()
                        cx, cy = float(c[0]), float(c[1])
                        if (cx < 15 or cy < 15 or cx > frame.shape[1] - 15 or cy > frame.shape[0] - 15):
                            warnings.append(f"Box {box_id} partially out of view")
                            break

            # Draw overlays
            draw_text_overlay(frame, messages)
            draw_warnings(frame, warnings)

            cv2.imshow(window_name, frame)
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break

    finally:
        # Close TCP connection first (send STOP command)
        if tcp_sender:
            print("\nClosing robot connection...")
            tcp_sender.close()

        if gripper_client:
            print("Closing gripper client...")
            gripper_client.close()
        
        # Close other resources
        logger.close()
        cam.release()
        cv2.destroyAllWindows()
        print(f"\n{'='*60}")
        print(f"Coordinates logged to: {args.log_csv}")
        print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
