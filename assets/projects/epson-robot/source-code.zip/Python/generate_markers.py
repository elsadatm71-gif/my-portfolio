"""
Generate ArUco markers for the multi-marker vision system.

This script creates marker images for:
- Origin marker (ID 0) - fixed on table
- Box markers (ID 10-13) - attached to boxes

Run this script to generate marker PNG files, then print them at the desired size.
Make sure all markers are the same physical size (e.g., 5cm × 5cm).
"""

import cv2
import os

# Create markers folder if it doesn't exist
os.makedirs("markers", exist_ok=True)

# Use the same dictionary as main.py
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)

# Marker size in pixels (will scale when printed)
marker_size_px = 200

# Generate origin marker (ID 0)
print("Generating origin marker (ID 0)...")
marker_image = cv2.aruco.generateImageMarker(aruco_dict, 0, marker_size_px)
cv2.imwrite("markers/marker_0_origin.png", marker_image)
print(f"  Saved: markers/marker_0_origin.png")

# Generate box markers (ID 10-13 → A/B/C/D)
destinations = {10: "A", 11: "B", 12: "C", 13: "D"}
for marker_id, dest in destinations.items():
    print(f"Generating box marker {marker_id} (destination {dest})...")
    marker_image = cv2.aruco.generateImageMarker(aruco_dict, marker_id, marker_size_px)
    cv2.imwrite(f"markers/marker_{marker_id}_dest_{dest}.png", marker_image)
    print(f"  Saved: markers/marker_{marker_id}_dest_{dest}.png")

print("\nAll markers generated!")
print("\nPrinting instructions:")
print("1. Open each marker PNG file")
print("2. Print at desired size (e.g., 5cm × 5cm)")
print("3. Use cardstock or laminate for durability")
print("4. Mount origin marker (ID 0) flat on table")
print("5. Attach box markers (ID 10-13) to box tops, flat surface")
print("\nMARK YOUR MARKERS WITH THEIR IDS FOR EASY IDENTIFICATION!")
