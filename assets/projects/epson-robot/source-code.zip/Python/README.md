# ESP32-CAM → Epson T3-401S SCARA Vision System

This project detects multiple ArUco markers to identify a workspace origin and box locations, calculates coordinates relative to the origin in centimeters, and provides validation/testing tools for accuracy assessment.

## Robot & Current Status

**Real Robot**: Epson T3-401S SCARA  
**Current Stage**: Vision system development & validation using Epson RC+ Virtual Controller (T6 Sample or T3 Sample)  
**Important**: No Python robot movement commands are generated yet. The Python project is focused entirely on computer vision, coordinate calculation, and validation. Robot communication will be added later when connecting to the real T3-401S over USB or Ethernet.

## System Overview

### Multiple Marker Detection

The system detects two types of ArUco markers:

1. **Origin Marker** (ID 0, fixed on table)
   - Defines the world coordinate system (0, 0)
   - Must be visible in every frame
   - Sets the reference frame for all coordinate calculations

2. **Box Markers** (IDs 10-13, attached to boxes)
   - Identify individual boxes
   - Map to destination locations (A, B, C, D)
   - Position calculated relative to origin marker

**Destination Mapping:**
- Marker ID 10 → Location A
- Marker ID 11 → Location B
- Marker ID 12 → Location C
- Marker ID 13 → Location D

## Current Project Scope

The Python vision system currently handles:

- **Multi-marker ArUco detection** via OpenCV
- **Origin marker tracking** as coordinate reference
- **Box marker identification** with ID-to-destination mapping
- **Relative coordinate calculation** in cm (box position relative to origin)
- **Box orientation calculation** (angle/yaw in degrees)
- **Coordinate filtering** (moving average per marker ID)
- **Stability validation** per marker ID
- **CSV logging** of all detections with timestamps
- **Real-time visualization** with grid, axes, and distance measurements
- **Calibration quality assessment** via reprojection error

### What NOT Included (Future)

❌ No Python robot movement commands  
❌ No TCP/serial communication to Epson RC+ yet  
❌ No real-time streaming to robot  
❌ No contour-based box detection (replaced by marker-based)

## Physical Setup

1. **Origin Marker (ID 0)**
   - Print an ArUco marker (ID 0) at your desired size (e.g., 5cm × 5cm)
   - Place it **flat on the work surface** under the ESP32-CAM
   - Position it so it's always visible in the camera frame
   - This marker defines (0, 0) in world coordinates

2. **Box Markers (IDs 10-13)**
   - Attach one ArUco marker to the top surface of each box
   - Use the same marker size as the origin marker (very important!)
   - Ensure markers are **flat and perpendicular** to the work surface
   - Each unique box should have a different marker ID

3. **Camera Setup**
   - Mount ESP32-CAM on a fixed stand pointing **straight down**
   - Position it to see both the origin marker and box markers clearly
   - Avoid shadows and tilting

## Quick Start

1. **Calibrate your camera** (recommended):

```bash
python calibrate.py
```

If your chessboard uses different dimensions, specify them:

```bash
python calibrate.py --cols 7 --rows 5
```



2. **Print ArUco Markers**

Use Python to generate marker images:

```python
import cv2
import numpy as np

# Generate origin marker (ID 0)
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
marker_image = cv2.aruco.generateImageMarker(aruco_dict, 0, 200)
cv2.imwrite("marker_0.png", marker_image)

# Generate box markers (ID 10-13)
for marker_id in [10, 11, 12, 13]:
    marker_image = cv2.aruco.generateImageMarker(aruco_dict, marker_id, 200)
    cv2.imwrite(f"marker_{marker_id}.png", marker_image)
```

3. **Run the vision system**:

```bash
# Basic run
python main.py --stream http://192.168.1.100:81/stream --marker-size-cm 5.0

# With debug output
python main.py --stream http://192.168.1.100:81/stream --marker-size-cm 5.0 --debug

# Custom calibration file
python main.py --stream http://192.168.1.100:81/stream --marker-size-cm 5.0 --calib calibration/calib.npz
```

## Command Line Arguments

- `--stream` (required): ESP32-CAM MJPEG stream URL
- `--marker-size-cm` (default: 5.0): Physical marker size in centimeters
- `--origin-marker-id` (default: 0): ID of the origin marker
- `--calib` (default: calibration/calib.npz): Path to calibration file
- `--log-csv` (default: coordinate_log.csv): CSV log file path
- `--stable-frames` (default: 5): Frames required for stability
- `--filter-window` (default: 6): Moving average window size
- `--position-threshold-cm` (default: 4.0): Position stability threshold
- `--angle-threshold-deg` (default: 3.0): Angle stability threshold
- `--debug`: Enable debug console output

## CSV Log Format

Each detection is logged with:

```
timestamp,box_marker_id,destination,x_cm,y_cm,angle_deg,distance_cm,stable
2024-05-29 10:15:32.123,10,A,12.34,56.78,15.0,61.2,1
```

- `timestamp`: When the measurement was taken
- `box_marker_id`: ArUco marker ID on the box
- `destination`: Mapped location (A/B/C/D)
- `x_cm`: X position relative to origin (cm)
- `y_cm`: Y position relative to origin (cm)
- `angle_deg`: Box rotation angle (degrees)
- `distance_cm`: Distance from origin (cm)
- `stable`: 1 if coordinates were stable, 0 if still filtering

## Display Overlay

The system shows on-screen:

- **Origin marker**: Green label "ORIGIN", axes visualization
- **Box markers**: Purple/magenta labels "BOX:ID", axes visualization
- **Connection line**: Yellow line from origin to each box
- **Coordinate info**: X, Y, angle, distance for each box
- **FPS**: Current frames per second
- **Calibration error**: Reprojection error in pixels
- **Stability**: Green circle (stable), orange circle (filtering)

## Folder Structure

- `src/`
  - `aruco_multi.py` - Multi-marker detection engine
  - `marker_config.py` - Configuration (marker IDs, destinations)
  - `smoothing.py` - Per-marker coordinate filtering
  - `coordinate_transform.py` - Pose transformations & relative calculations
  - `camera.py` - ESP32-CAM stream handler
  - `calibration.py` - Camera calibration utilities
- `calibration/` - Calibration output (calib.npz)
- `calibration_images/` - Checkerboard images for calibration
- `main.py` - Vision system entry point
- `calibrate.py` - Camera calibration script
- `requirements.txt` - Dependencies

## Camera Calibration

Camera calibration is **critical** for accurate coordinate measurement:

1. Print a checkerboard pattern (e.g., 9×6 inner corners)
2. Take 20-30 photos of the checkerboard at different angles under the camera
3. Save images in `calibration_images/`
4. Run: `python calibrate.py`
5. Check the reprojection error (should be <1.5 pixels)

For more details, see [OpenCV calibration guide](https://docs.opencv.org/master/d4/d94/tutorial_camera_calibration.html).

## Coordinate System

- **Origin**: Center of origin marker (ID 0) at Z=0
- **X-axis**: Right (positive to the right when looking down)
- **Y-axis**: Forward/Up (positive away from camera perspective)
- **Z-axis**: Up (normal to the table surface)
- **Unit**: Centimeters

## Troubleshooting

**"Calibration file not found"**
- Run `python calibrate.py` to generate calibration/calib.npz

**"Origin marker NOT detected"**
- Ensure marker ID 0 is visible in the camera frame
- Check lighting conditions
- Verify marker size matches --marker-size-cm

**"No BOX markers detected"**
- Verify box markers have correct IDs (10, 11, 12, 13)
- Ensure markers are flat and visible
- Check marker size consistency

**High calibration error (>3px)**
- Recalibrate camera with more checkerboard images
- Ensure camera is not tilted
- Use uniform lighting without shadows

## Future: Robot Communication

When the real Epson T3-401S is connected (via USB or Ethernet), the project will:

1. Accept real controller connection in Epson RC+
2. Stream stable box coordinates in format: `X,Y,Angle,Destination`
3. Receive pickup confirmation from robot
4. Update feedback loop for multiple box handling

Until then, all coordinates are logged to CSV for analysis and validation.

## ESP32-CAM Tips

- Use smaller resolution (320x240) on the ESP32-CAM for higher FPS
- Use MJPEG stream (`/stream`) instead of single-frame HTTP fetch
- Reduce on-board image processing and disable face detection
- Use hardware PSRAM if available and set JPEG quality lower

## License

MIT
