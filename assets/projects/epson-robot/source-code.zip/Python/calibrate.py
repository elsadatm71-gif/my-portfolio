#!/usr/bin/env python3
"""Camera calibration pipeline for ESP32-CAM.

Reads all checkerboard images from calibration_images/, detects inner corners,
calibrates the camera, and saves camera_matrix/dist_coeffs to calibration/calib.npz.
"""

import argparse
import glob
import os
import sys

import cv2
import numpy as np

COMMON_FALLBACK_PATTERNS = [
    (5, 7),
    (7, 5),
    (6, 9),
    (9, 6),
    (6, 8),
    (8, 6),
]


def parse_args():
    parser = argparse.ArgumentParser(description="ESP32-CAM camera calibration tool")
    parser.add_argument(
        "--images",
        default="calibration_images/*.*",
        help="glob for calibration images (default: calibration_images/*.*)",
    )
    parser.add_argument(
        "--rows",
        type=int,
        default=6,
        help="number of inner checkerboard rows (default: 6)",
    )
    parser.add_argument(
        "--cols",
        type=int,
        default=9,
        help="number of inner checkerboard columns (default: 9)",
    )
    parser.add_argument(
        "--square-size-mm",
        type=float,
        default=33.0,
        help="checkerboard square size in millimeters (default: 33)",
    )
    parser.add_argument(
        "--output",
        default="calibration/calib.npz",
        help="output calibration file path (default: calibration/calib.npz)",
    )
    parser.add_argument(
        "--visualize",
        action="store_true",
        help="show checkerboard detection visualization",
    )
    parser.add_argument(
        "--delay-ms",
        type=int,
        default=300,
        help="delay between visualization frames in milliseconds (default: 300)",
    )
    return parser.parse_args()


def build_object_points(rows, cols, square_size_mm):
    objp = np.zeros((rows * cols, 3), np.float32)
    objp[:, :2] = np.mgrid[0:cols, 0:rows].T.reshape(-1, 2)
    objp *= square_size_mm / 1000.0
    return objp


def collect_image_paths(image_glob):
    image_paths = sorted(glob.glob(image_glob))
    if not image_paths:
        raise FileNotFoundError(f"No calibration images found for glob: {image_glob}")
    return image_paths


def detect_corners(image_path, rows, cols):
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Unable to load image: {image_path}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
    found, corners = cv2.findChessboardCorners(gray, (cols, rows), flags)
    if not found:
        return image, None

    criteria = (cv2.TermCriteria_EPS + cv2.TermCriteria_MAX_ITER, 30, 0.001)
    corners_refined = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
    cv2.drawChessboardCorners(image, (cols, rows), corners_refined, found)
    return image, corners_refined


def collect_pattern_points(image_paths, rows, cols, square_size_mm, visualize=False, delay_ms=300):
    objpoints = []
    imgpoints = []
    successful_images = []
    failed_images = []
    objp = build_object_points(rows, cols, square_size_mm)
    last_gray_shape = None

    for image_path in image_paths:
        try:
            preview, corners = detect_corners(image_path, rows, cols)
        except Exception as exc:
            failed_images.append(image_path)
            print(f"[ERROR] {image_path}: {exc}")
            continue

        if corners is None:
            failed_images.append(image_path)
            print(f"[FAILED] No corners found: {image_path}")
        else:
            objpoints.append(objp)
            imgpoints.append(corners)
            successful_images.append(image_path)
            last_gray_shape = preview.shape[1], preview.shape[0]
            print(f"[OK] Corners detected: {image_path}")

        if visualize:
            cv2.imshow("Calibration Checkerboard", preview)
            if cv2.waitKey(delay_ms) & 0xFF == ord("q"):
                print("Visualization interrupted by user.")
                break

    if visualize:
        cv2.destroyAllWindows()

    return objpoints, imgpoints, successful_images, failed_images, last_gray_shape


def calibrate_camera(image_paths, rows, cols, square_size_mm, visualize=False, delay_ms=300):
    objpoints, imgpoints, successful_images, failed_images, last_gray_shape = collect_pattern_points(
        image_paths, rows, cols, square_size_mm, visualize, delay_ms
    )

    used_rows, used_cols = rows, cols
    if not objpoints:
        print(f"No corners found for requested pattern {cols}x{rows}. Trying common fallback patterns...")
        for fallback_rows, fallback_cols in COMMON_FALLBACK_PATTERNS:
            if fallback_rows == rows and fallback_cols == cols:
                continue
            print(f"Testing fallback pattern {fallback_cols}x{fallback_rows}...")
            objpoints, imgpoints, successful_images, failed_images, last_gray_shape = collect_pattern_points(
                image_paths, fallback_rows, fallback_cols, square_size_mm, visualize, delay_ms
            )
            if objpoints:
                used_rows, used_cols = fallback_rows, fallback_cols
                print(f"Using detected pattern {fallback_cols}x{fallback_rows} instead of requested {cols}x{rows}.")
                break

    if not objpoints:
        raise RuntimeError("No checkerboard corners were found in any calibration image.")

    image_size = last_gray_shape
    if image_size is None:
        raise RuntimeError("Unable to determine image size for calibration.")

    retval, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
        objpoints,
        imgpoints,
        image_size,
        None,
        None,
    )

    total_error = 0.0
    for objp_i, imgp_i, rvec, tvec in zip(objpoints, imgpoints, rvecs, tvecs):
        projected, _ = cv2.projectPoints(objp_i, rvec, tvec, camera_matrix, dist_coeffs)
        total_error += cv2.norm(imgp_i, projected, cv2.NORM_L2) / len(projected)

    mean_error = total_error / len(objpoints)
    return {
        "camera_matrix": camera_matrix,
        "dist_coeffs": dist_coeffs,
        "reprojection_error": float(mean_error),
        "successful_images": successful_images,
        "failed_images": failed_images,
        "image_count": len(image_paths),
        "rows": used_rows,
        "cols": used_cols,
    }


def save_calibration(output_path, data, rows, cols, square_size_mm):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    np.savez(
        output_path,
        camera_matrix=data["camera_matrix"],
        dist_coeffs=data["dist_coeffs"],
        reprojection_error=data["reprojection_error"],
        rows=rows,
        cols=cols,
        square_size_mm=square_size_mm,
    )
    print(f"Saved calibration to {output_path}")


def main():
    args = parse_args()
    image_paths = collect_image_paths(args.images)
    print(f"Found {len(image_paths)} calibration image(s).")
    print(f"Checkerboard: {args.cols} x {args.rows} inner corners, {args.square_size_mm} mm squares.")

    try:
        result = calibrate_camera(
            image_paths,
            rows=args.rows,
            cols=args.cols,
            square_size_mm=args.square_size_mm,
            visualize=args.visualize,
            delay_ms=args.delay_ms,
        )
    except Exception as exc:
        print(f"Calibration failed: {exc}")
        sys.exit(1)

    print("\nCalibration summary:")
    print(f"  Total images: {len(image_paths)}")
    print(f"  Successful images: {len(result['successful_images'])}")
    print(f"  Failed images: {len(result['failed_images'])}")
    print(f"  Calibration pattern used: {result.get('cols', args.cols)} x {result.get('rows', args.rows)} inner corners")
    print(f"  Reprojection error: {result['reprojection_error']:.6f}")
    if result["failed_images"]:
        print("  Failed image files:")
        for filename in result["failed_images"]:
            print(f"    - {filename}")
    save_calibration(
        args.output,
        result,
        result.get("rows", args.rows),
        result.get("cols", args.cols),
        args.square_size_mm,
    )

    print("\nCalibration succeeded.")
    print("Use the generated calibration file in main.py with --calib calibration/calib.npz")


if __name__ == "__main__":
    main()
