import argparse
import time
import sys
from urllib.parse import urlparse, urlunparse

import cv2
import numpy as np

try:
    import serial
except ImportError:
    serial = None


def parse_args():
    parser = argparse.ArgumentParser(
        description="Detect ArUco markers, measure pose, and send a pickup command when aligned."
    )
    parser.add_argument("--camera", type=int, default=0, help="USB camera index")
    parser.add_argument("--camera-url", type=str, default='http://192.168.137.245:81/stream', help="IP camera stream URL (e.g. http://192.168.137.245:81/stream)")
    parser.add_argument("--serial", type=str, default=None, help="Serial port for machine command (e.g. COM3)")
    parser.add_argument("--baud", type=int, default=115200, help="Serial baud rate")
    parser.add_argument("--aruco", type=str, default="DICT_4X4_50", help="ArUco dictionary name")
    parser.add_argument("--marker-id", type=int, default=None, help="Track only this ArUco marker ID")
    parser.add_argument("--marker-mm", type=float, default=100.0, help="Actual ArUco marker side length in millimeters")
    parser.add_argument("--target-x-mm", type=float, default=20.0, help="Allowed horizontal offset from camera center in mm")
    parser.add_argument("--target-y-mm", type=float, default=20.0, help="Allowed vertical offset from camera center in mm")
    parser.add_argument("--target-z-mm", type=float, default=50.0, help="Allowed distance tolerance in mm")
    parser.add_argument("--distance-target-mm", type=float, default=0.0, help="Target marker distance in mm (0 = ignore)")
    parser.add_argument("--send-command", action="store_true", help="Send the pickup command when aligned")
    parser.add_argument("--command", type=str, default="PICKUP\n", help="Command text to send to the machine")
    parser.add_argument("--cooldown", type=float, default=1.5, help="Seconds between pickup command sends")
    parser.add_argument("--camera-matrix", type=str, default=None, help="YAML file path for camera intrinsics")
    parser.add_argument("--dist-coeffs", type=str, default=None, help="YAML file path for distortion coefficients")
    parser.add_argument("--focal-length-px", type=float, default=700.0, help="Fallback focal length in pixels if no calibration is provided")
    parser.add_argument("--show-zone", action="store_true", help="Draw the alignment target zone on screen")
    return parser.parse_args()


def load_camera_calibration(yaml_file):
    fs = cv2.FileStorage(yaml_file, cv2.FILE_STORAGE_READ)
    if not fs.isOpened():
        raise FileNotFoundError(f"Could not open calibration file: {yaml_file}")
    data = {}
    for key in ["camera_matrix", "dist_coeffs"]:
        node = fs.getNode(key)
        if node.empty():
            continue
        data[key] = node.mat()
    fs.release()
    return data


def get_aruco_dictionary(name):
    dictionaries = {
        "DICT_4X4_50": cv2.aruco.DICT_4X4_50,
        "DICT_4X4_100": cv2.aruco.DICT_4X4_100,
        "DICT_4X4_250": cv2.aruco.DICT_4X4_250,
        "DICT_6X6_50": cv2.aruco.DICT_6X6_50,
        "DICT_6X6_100": cv2.aruco.DICT_6X6_100,
        "DICT_7X7_50": cv2.aruco.DICT_7X7_50,
        "DICT_7X7_100": cv2.aruco.DICT_7X7_100,
        "DICT_5X5_100": cv2.aruco.DICT_5X5_100,
        "DICT_5X5_250": cv2.aruco.DICT_5X5_250,
        "DICT_5X5_1000": cv2.aruco.DICT_5X5_1000,
    }
    if name not in dictionaries:
        raise ValueError(f"Unsupported ArUco dictionary: {name}")
    return cv2.aruco.getPredefinedDictionary(dictionaries[name])


def compute_distance(marker_size_mm, pixel_length, focal_length_px):
    if focal_length_px <= 0 or pixel_length <= 0:
        return None
    return marker_size_mm * (focal_length_px / pixel_length)


def draw_alignment_zone(frame, width, height, config):
    if not config.show_zone:
        return
    zone_width = int((config.target_x_mm / config.marker_mm) * width * 0.5)
    zone_height = int((config.target_y_mm / config.marker_mm) * height * 0.5)
    center = (width // 2, height // 2)
    upper_left = (center[0] - zone_width, center[1] - zone_height)
    lower_right = (center[0] + zone_width, center[1] + zone_height)
    cv2.rectangle(frame, upper_left, lower_right, (255, 255, 0), 2)
    cv2.putText(
        frame,
        f"Zone: {config.target_x_mm:.0f}x{config.target_y_mm:.0f}mm",
        (10, height - 20),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (255, 255, 0),
        2,
    )


def find_marker_index(ids, target_id):
    if target_id is None:
        return 0
    for idx, marker_id in enumerate(ids.flatten()):
        if marker_id == target_id:
            return idx
    return None


def detect_box(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    edges = cv2.Canny(th, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(c)
    if area < 500:
        return None
    x, y, w, h = cv2.boundingRect(c)
    cx = x + w / 2.0
    cy = y + h / 2.0
    return {"bbox": (x, y, w, h), "center": (cx, cy), "area": area}


def get_base_urls(url):
    parsed = urlparse(url)
    if not parsed.scheme:
        parsed = parsed._replace(scheme="http")
    base_with_port = urlunparse((parsed.scheme, parsed.netloc or parsed.path, "", "", "", ""))
    host = parsed.hostname or parsed.path
    base_host = urlunparse((parsed.scheme, host, "", "", "", ""))
    urls = []
    if base_with_port and base_with_port not in urls:
        urls.append(base_with_port)
    if base_host and base_host not in urls:
        urls.append(base_host)
    return urls


def main():
    args = parse_args()

    if args.send_command and args.serial is None:
        print("Warning: --send-command was requested, but no --serial port was configured.")

    if args.serial and serial is None:
        print("Error: pyserial is required to use a serial port. Install it with `pip install pyserial`.")
        sys.exit(1)

    stream_url = None
    stream_candidates = []
    if args.camera_url:
        print(f"Opening IP camera stream: {args.camera_url}")
        stream_candidates = [args.camera_url]
        stream_candidates.extend(get_base_urls(args.camera_url))
        # preserve order and unique values
        stream_candidates = list(dict.fromkeys(stream_candidates))
        stream_url = stream_candidates[0]
        device = cv2.VideoCapture(stream_url)
    else:
        device = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)

    if not device.isOpened():
        if args.camera_url:
            print(f"Unable to open camera URL {stream_url}")
            for fallback_url in stream_candidates[1:]:
                print(f"Trying fallback URL: {fallback_url}")
                device = cv2.VideoCapture(fallback_url)
                if device.isOpened():
                    stream_url = fallback_url
                    break
            if not device.isOpened():
                print("All camera URL attempts failed.")
                sys.exit(1)
        else:
            print(f"Unable to open camera index {args.camera}")
            sys.exit(1)

    device.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    cv2.namedWindow("Aruco Pickup", cv2.WINDOW_NORMAL)

    width = int(device.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
    height = int(device.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
    image_center = np.array([width / 2.0, height / 2.0], dtype=float)

    cam_matrix = None
    dist_coeffs = None
    if args.camera_matrix:
        calibration = load_camera_calibration(args.camera_matrix)
        cam_matrix = calibration.get("camera_matrix")
        dist_coeffs = calibration.get("dist_coeffs", np.zeros((5, 1), np.float64))

    marker_dictionary = get_aruco_dictionary(args.aruco)
    parameters = cv2.aruco.DetectorParameters_create()

    ser = None
    if args.serial:
        ser = serial.Serial(args.serial, args.baud, timeout=1)
        time.sleep(1.0)
        print(f"Opened serial port {args.serial} at {args.baud} baud")

    last_sent = 0.0
    focal_length = args.focal_length_px

    current_candidate_index = 0
    print("Starting ArUco detection. Press ESC to exit.")
    while True:
        success, frame = device.read()
        if not success or frame is None:
            print("Camera frame capture failed. Retrying...")
            if stream_url and stream_candidates:
                time.sleep(1.0)
                device.release()
                current_candidate_index += 1
                if current_candidate_index < len(stream_candidates):
                    stream_url = stream_candidates[current_candidate_index]
                    print(f"Switching to fallback URL: {stream_url}")
                    device = cv2.VideoCapture(stream_url)
                    device.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                    continue
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = cv2.aruco.detectMarkers(gray, marker_dictionary, parameters=parameters)
        if corners:
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

        aligned = False
        status_text = "No marker detected"

        if ids is not None and len(ids) > 0:
            marker_idx = find_marker_index(ids, args.marker_id)
            if marker_idx is None:
                status_text = f"Marker {args.marker_id} not found"
            else:
                marker_corners = corners[marker_idx].reshape((4, 2))
                top_left, top_right, bottom_right, bottom_left = marker_corners
                pixel_edge = np.linalg.norm(top_right - top_left)
                pixel_height = np.linalg.norm(top_left - bottom_left)
                pixel_size = (pixel_edge + pixel_height) / 2.0
                marker_center = np.mean(marker_corners, axis=0)
                cv2.circle(frame, tuple(marker_center.astype(int)), 5, (0, 255, 0), -1)

                distance_mm = None
                x_mm = None
                y_mm = None
                z_mm = None

                if cam_matrix is not None:
                    corners_array = np.array([marker_corners], dtype=np.float32)
                    rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                        corners_array,
                        args.marker_mm / 1000.0,
                        cam_matrix,
                        dist_coeffs,
                    )
                    if tvecs is not None and len(tvecs) > 0:
                        tvec = tvecs[0][0]
                        x_mm = float(tvec[0] * 1000.0)
                        y_mm = float(tvec[1] * 1000.0)
                        z_mm = float(tvec[2] * 1000.0)
                        distance_mm = float(np.linalg.norm(tvec) * 1000.0)
                        cv2.drawFrameAxes(frame, cam_matrix, dist_coeffs, rvecs[0], tvec, 0.05)
                if distance_mm is None:
                    distance_mm = compute_distance(args.marker_mm, pixel_size, focal_length)
                    if distance_mm is not None:
                        pixel_offset = marker_center - image_center
                        x_mm = float(pixel_offset[0] * distance_mm / focal_length)
                        y_mm = float(pixel_offset[1] * distance_mm / focal_length)
                        z_mm = distance_mm

                if distance_mm is not None and x_mm is not None and y_mm is not None and z_mm is not None:
                    offset_mm = np.linalg.norm([x_mm, y_mm])
                    aligned = (
                        abs(x_mm) <= args.target_x_mm
                        and abs(y_mm) <= args.target_y_mm
                        and (args.distance_target_mm == 0.0 or abs(z_mm - args.distance_target_mm) <= args.target_z_mm)
                    )
                    status_text = (
                        f"ID:{ids.flatten()[marker_idx]} Dist:{distance_mm:.0f}mm "
                        f"X:{x_mm:.0f}mm Y:{y_mm:.0f}mm"
                    )
                    cv2.putText(
                        frame,
                        status_text,
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),
                        2,
                    )
                    cv2.arrowedLine(
                        frame,
                        tuple(image_center.astype(int)),
                        tuple(marker_center.astype(int)),
                        (255, 0, 0),
                        2,
                        tipLength=0.05,
                    )
                    cv2.circle(frame, tuple(image_center.astype(int)), 4, (0, 128, 255), -1)

                    if aligned:
                        alignment_text = "Aligned: ready to pickup"
                        text_color = (0, 255, 0)
                        send_pickup = True
                    else:
                        alignment_text = (
                            f"Not aligned X:{abs(x_mm):.0f}/{args.target_x_mm:.0f} "
                            f"Y:{abs(y_mm):.0f}/{args.target_y_mm:.0f}"
                        )
                        text_color = (0, 165, 255)
                    cv2.putText(frame, alignment_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, text_color, 2)
                else:
                    status_text = "Marker detected, pose unavailable"
                    cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

                # Detect a nearby box and compute its 3D coordinates using the marker depth
                box = detect_box(frame)
                if box is not None:
                    bx, by = box["center"]
                    x0 = None
                    y0 = None
                    z0 = None
                    # intrinsics
                    if cam_matrix is not None:
                        fx = float(cam_matrix[0, 0])
                        fy = float(cam_matrix[1, 1])
                        cx = float(cam_matrix[0, 2])
                        cy = float(cam_matrix[1, 2])
                    else:
                        fx = fy = float(focal_length)
                        cx = width / 2.0
                        cy = height / 2.0

                    z_box_mm = z_mm if (z_mm is not None) else distance_mm
                    if z_box_mm is not None and fx > 0:
                        x0 = (bx - cx) * z_box_mm / fx
                        y0 = (by - cy) * z_box_mm / fy
                        z0 = z_box_mm
                        cv2.rectangle(frame, (int(box["bbox"][0]), int(box["bbox"][1])), (int(box["bbox"][0]+box["bbox"][2]), int(box["bbox"][1]+box["bbox"][3])), (0,255,255), 2)
                        cv2.circle(frame, (int(bx), int(by)), 4, (0,255,255), -1)
                        cv2.putText(frame, f"Box X:{x0:.0f}mm Y:{y0:.0f}mm Z:{z0:.0f}mm", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,255), 2)

        draw_alignment_zone(frame, width, height, args)
        cv2.imshow("Aruco Pickup", frame)

        if aligned and args.send_command and ser is not None:
            now = time.time()
            if now - last_sent > args.cooldown:
                ser.write(args.command.encode("utf-8"))
                print(f"Sent pickup command: {args.command.strip()}")
                last_sent = now

        key = cv2.waitKey(1) & 0xFF
        if key == 27:
            break

    if ser is not None and ser.is_open:
        ser.close()
    device.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
